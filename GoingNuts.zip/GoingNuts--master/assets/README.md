This directory, the assets directory, is for all the projects assets. Those being all things not source code.
