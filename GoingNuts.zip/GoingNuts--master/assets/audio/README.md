This directory, the audio directory, is for all audio assets. 
