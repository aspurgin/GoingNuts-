This directory, the sfx directory, is for all sound effects assets.
