This directory, the tracks directory, is for all audio tracks, not including sound effects.
