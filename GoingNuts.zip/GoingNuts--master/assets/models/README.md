This directory, the models directory, is for all 3D assets.
