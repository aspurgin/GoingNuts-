This directory, the textures directory, is for all 2D assets.
