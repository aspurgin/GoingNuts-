This directory, the docs directory, is for all the documentation of the project.
