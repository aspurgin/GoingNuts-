This directory, the src directory, contains all the code for the project.
