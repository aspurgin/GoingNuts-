#ifndef __BLOCKTYPE_H_
#define __BLOCKTYPE_H_

#define DIRTBLOCK  0
#define STONEBLOCK 1
#define SANDBLOCK 2
#define CRYSTALBLOCK 3
#define LAVABLOCK 4

#endif
