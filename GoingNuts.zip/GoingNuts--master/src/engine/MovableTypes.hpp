#ifndef __MOVABLETYPE_H_
#define __MOVABLETYPE_H_

#define PLAYER 1
#define BLOCK 2
#define NUT 3
#define HARDHAT 4
#define SUPERDRILL 5
#define DYNAMITE 6

#endif
