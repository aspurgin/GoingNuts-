#ifndef Number6_HPP
#define Number6_HPP

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "../helperFiles/MStackHelp.h"
#include "../assets/Assets.hpp"
#include "../hud/Number.hpp"

class Number6 : public Number {
   public:
      Number6();
      void render();
};

#endif