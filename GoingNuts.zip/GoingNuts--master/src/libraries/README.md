This directory, the library directory, is for all external libraries and code that was not written by us.
