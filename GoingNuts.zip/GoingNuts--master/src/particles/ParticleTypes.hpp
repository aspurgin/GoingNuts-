/*
 * ParticleTypes.hpp
 *
 *  Created on: Jun 9, 2014
 *      Author: jfujikaw
 */

#ifndef PARTICLETYPES_HPP_
#define PARTICLETYPES_HPP_

#define CRYSTAL 1
#define SAND 2
#define SPARK 3
#define LAVA 4

#endif /* PARTICLETYPES_HPP_ */
