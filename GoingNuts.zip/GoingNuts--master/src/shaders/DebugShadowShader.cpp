#include "DebugShadowShader.hpp"

DebugShadowShader::DebugShadowShader() {
	
}