#include "FlatTextureShader.hpp"

FlatTextureShader::FlatTextureShader() {
}

void FlatTextureShader::setMaterial(int i) {
}
