#include "LightMapShader.hpp"

LightMapShader::LightMapShader() {
	
}