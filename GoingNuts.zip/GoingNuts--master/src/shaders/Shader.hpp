#ifndef _SHADERCLASS
#define _SHADERCLASS

class Shader {

};

#endif